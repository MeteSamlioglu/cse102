 /*
** hw5_lib.c:
**
** The source file implementing library functions.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.04.02.23.55
** 
*/

#include <stdio.h>
#include<math.h>
#include "hw5_lib.h"


/* Part 1 */
void check_polynomial_inputs(double *a3, double *a2, double *a1, double *a0){ /* Input control function */
char left_paranthesis, right_paranthesis, comma, end_char;
    int i=0, degree=0, degree3_control=0, degree2_control=0, degree1_control=0, degree0_control=0, stop_condition;
    double coeff=0.0;
    while(1){
        degree3_control=0; 
        degree2_control=0; 
        degree1_control=0; 
        degree0_control=0;
        stop_condition=1;
        printf("Please enter the coefficients :");
		for(i=0;i<4;i++){
            scanf(" %c%d%c %lf%c%c",&left_paranthesis,&degree,&comma,&coeff,&right_paranthesis,&end_char); /* Get first paranthesis and its values */
            if(left_paranthesis!='(' || right_paranthesis!=')' || comma!=',' || (degree>3 && degree<0)|| /* Error Conditions */
                degree3_control>1 || degree2_control>1 || degree1_control>1 || degree0_control>1){
                stop_condition=0;
            
             }
            if(i<3){
                if(end_char!=','){       /* After each paranthesis there must be "," otherwise there will be error */
                    stop_condition=0;
                }
            }else if(i==3){           /* End char must be include "." */
                if(end_char!='.'){
                    stop_condition=0;
                }
            }
            
            if(degree==3){       /* read the inputs properly */
                *a3=coeff;
                degree3_control++;
            }
            else if(degree==2){
                *a2=coeff;
                degree2_control++;
            }
            else if(degree==1){
                *a1=coeff;
                degree1_control++;
            }
            else if(degree==0){
                *a0=coeff;
                degree0_control++;
            }
        }
        if(stop_condition==1){     
            break;
        }
        else{
            printf("\nERROR: Input format must be as showed in below !\n");    /* Error Message */
            printf("(3, a), (2, b), (1, c), (0, d).\n"); 
        }
    
    }    

}

void operate_polynomials  (double *a3, double *a2, double *a1, double *a0, double *b3, double *b2, double *b1, double *b0, char op)
{
    double x_6, x_5, x_4, x_3, x_2, x_1, x_0;
	printf("First polynomial's coefficients...\n");      /* Read the coefficients of polynomials properly */
	check_polynomial_inputs(a3,a2,a1,a0);
    printf("Second polynomial's coefficients...\n");
    check_polynomial_inputs(b3,b2,b1,b0);
    
    if(op=='+'){           /* Addition operator */
        *a3+=*b3;
        *a2+=*b2;
        *a1+=*b1;
        *a0+=*b0;
    }
    else if(op=='-')  /* Subtraction operator */
    {
        *a3-=*b3;
        *a2-=*b2;
        *a1-=*b1;
        *a0-=*b0;
    }
    else if(op=='*')        /* Multiply operator */
    {
        x_6=(*a3)*(*b3);                             /* 3rd multiplication */
        x_5=(*a3)*(*b2)+(*b3)*(*a2);
        x_4=(*a3)*(*b1)+(*a2)*(*b2)+(*a1)*(*b3);
        x_3=(*a3)*(*b0)+(*a2)*(*b1)+(*a1)*(*b2)+(*a0)*(*b3);
        x_2=(*a2)*(*b0)+(*a1)*(*b1)+(*a0)*(*b2);
        x_1=(*a1)*(*b0)+(*a0)*(*b1);
        x_0=(*a0)*(*b0);
        *a3=x_6;             /* Send new coeffs to the test_function  */
        *a2=x_5;
        *a1=x_4;
        *a0=x_3;
        *b3=x_2;
        *b2=x_1;
        *b1=x_0;

    }
}

/* Part 2 */
void four_d_vectors (double* mean_a0, double* mean_a1, double* mean_a2, double* mean_a3, double* longest_distance, int N)
{
	double d0, d1, d2, d3, euclidian_distance;
	double a0 ,a1, a2, a3, b0, b1, b2, b3, distance;
    int i=0, counter=0;
    for(i=1;i<N;i++){           /* Read consecutive N 4d vector */
        
        if(counter==0)
            printf("Please enter the dimensions [a0 a1 a2 a3 ]:");
        
        if(counter==0){
            scanf("%lf%lf%lf%lf",&a0,&a1,&a2,&a3);
            printf("Please enter the dimensions [a0 a1 a2 a3 ]:");
            scanf("%lf%lf%lf%lf",&b0,&b1,&b2,&b3);
            if(a0==-1 && a1==-1 && a2==-1 && a3==-1)        /* Break condition */
                break;
            else if(b0==-1 && b1==-1 && b2==-1 && b3==-1)
                break;
        
            d0=pow(b0-a0,2);          /* Finding the distance and pass it as a argument to the following function */
            d1=pow(b1-a1,2);
            d2=pow(b2-a2,2);
            d3=pow(b3-a3,2);   
            distance_between_4d_points (d0, d1, d2, d3, &euclidian_distance); 
            *longest_distance=euclidian_distance;
            *mean_a0=a0+b0;         /* Each dimension's mean calculation */
            *mean_a1=a1+b1;
            *mean_a2=a2+b2;
            *mean_a3=a3+b3;     
        }
        else if(counter%2!=0){
            printf("Please enter the dimensions [a0 a1 a2 a3 ]:");
            scanf("%lf%lf%lf%lf",&a0,&a1,&a2,&a3);
            if(a0==-1 && a1==-1 && a2==-1 && a3==-1)
                break;
            d0=pow(b0-a0,2);
            d1=pow(b1-a1,2);
            d2=pow(b2-a2,2);
            d3=pow(b3-a3,2);
            distance_between_4d_points (d0, d1, d2, d3, &euclidian_distance); 
            *mean_a0+=a0;
            *mean_a1+=a1;
            *mean_a2+=a2;
            *mean_a3+=a3;
        }
        else{
            printf("Please enter the dimensions [a0 a1 a2 a3 ]:");
            scanf("%lf%lf%lf%lf",&b0,&b1,&b2,&b3);
            if(b0==-1 && b1==-1 && b2==-1 && b3==-1)
                break;
            d0=pow(b0-a0,2);
            d1=pow(b1-a1,2);
            d2=pow(b2-a2,2);
            d3=pow(b3-a3,2);   
            distance_between_4d_points (d0, d1, d2, d3, &euclidian_distance);
            *mean_a0+=b0;
            *mean_a1+=b1;
            *mean_a2+=b2;
            *mean_a3+=b3;
    
         }
        
        if(euclidian_distance>=*longest_distance)   /* Finding the longest euclidian distance by comparing consecutive Function's distance values */
            *longest_distance=euclidian_distance;
       
        counter++;
      }
    counter++;/* We got two input in for loop when i=1, Therefore we need to increment counter to determine accurate vector count */
    /* Dimensions mean calculation */
    *mean_a0=(*mean_a0)/counter;     /* Mean=(Sum of dimensions)/vector_count */
    *mean_a1=(*mean_a1)/counter;
    *mean_a2=(*mean_a2)/counter;
    *mean_a3=(*mean_a3)/counter;
}


void distance_between_4d_points (double d0, double d1, double d2, double d3, double* euclidian_distance)
{
    *euclidian_distance=sqrt(d0+d1+d2+d3);         /* Distance expression */
}


/* Part 3 */
void find_max(int* partyA, int* partyB, int* partyC, int* partyD, int* partyE, int *op){
                            /* To determine which party won in each iteration */
if(*partyE>=*partyA)       /* If all the parties have the same vote, Determined priority is as follows partyA>partyB>partyC>partyD>partyE */
    if(*partyE>=*partyB)
        if(*partyE>=*partyC)
            if(*partyE>=*partyD)
                *op=5;

if(*partyD>=*partyA)
    if(*partyD>=*partyB)
        if(*partyD>=*partyC)
            if(*partyD>=*partyE)
                *op=4;

if(*partyC>=*partyA)
    if(*partyC>=*partyB)
        if(*partyC>=*partyD)
            if(*partyC>=*partyE)
                *op=3;   

if(*partyB>=*partyA)
    if(*partyB>=*partyC)
        if(*partyB>=*partyD)
            if(*partyB>=*partyE)
                *op=2;

if(*partyA>=*partyB)
    if(*partyA>=*partyC)
        if(*partyA>=*partyD)
            if(*partyA>=*partyE)
                *op=1;

}

void dhondt_method (int* partyA, int* partyB, int* partyC, int* partyD, int* partyE, int numberOfSeats)
{
	int op;
    int divider_a=1, divider_b=1, divider_c=1, divider_d=1, divider_e=1;
    int initial_partyA=*partyA, initial_partyB=*partyB, initial_partyC=*partyC, initial_partyD=*partyD, initial_partyE=*partyE;
    int a=0, b=0, c=0, d=0, e=0;
    
    while(numberOfSeats!=0){
        find_max(partyA,partyB,partyC,partyD,partyE,&op);
        switch(op){
        case 1:
            divider_a++;
            *partyA=initial_partyA/divider_a;
            a++;
            numberOfSeats--;
        break;
        case 2:
            divider_b++;
            *partyB=initial_partyB/divider_b;
            b++;
            numberOfSeats--;
        break;
        case 3:
            divider_c++;
            *partyC=initial_partyC/divider_c;
            c++;
            numberOfSeats--; 
        break;
        case 4:
            divider_d++;
            *partyD=initial_partyD/divider_d;
            d++;
            numberOfSeats--;
        break;
        case 5:
            divider_e++;
            *partyE=initial_partyE/divider_e;
            e++;
            numberOfSeats--;
        break;
        default:
        break;
         }
    }
    *partyA=a;          /* Return the values to the test_function */
    *partyB=b;
    *partyC=c;
    *partyD=d;
    *partyE=e;

}


/* Part 4 */

void order_2d_points_cc (double* x1, double* y1, double* x2, double* y2, double* x3, double* y3)
{
	printf("TO BE IMPLEMENTED\n");      /* I did not handle this algorithm, Actually I found a solution but it was so complicated*/
}                                       /* Briefly, I did not implement an easy algorithm to handle this problem. */

/* Part 5 */

void number_encrypt (unsigned char* number)
{
	char b7='-', b6='-', b5='-', b4='-', b3='-', b2='-', b1='-', b0='-';
	get_number_components (*number, &b7, &b6, &b5, &b4, &b3, &b2, &b1, &b0);
	reconstruct_components (number, b7, b6, b5, b4, b3, b2, b1, b0);
	
}

void assing_zero(int missing_digit,char *b7, char* b6, char* b5, char* b4, char* b3, char* b2, char* b1, char *b0){
    
    int counter_digits=0;                          /*When we convert our decimal value to the binary */
    missing_digit=8-missing_digit;                 /* If binary representation of the decimal number is less than 8 digit */
    while(counter_digits<missing_digit){           /* Add 0 in front of the binary representation till it has 8 digit */
                                                   /*Example  1001-->0001001 */
    if(counter_digits==0)
        *b7=0;
    else if(counter_digits==1)
        *b6=0;
    else if(counter_digits==2)
        *b5=0;
    else if(counter_digits==3)
        *b4=0;
    else if(counter_digits==4)
        *b3=0;
    else if(counter_digits==5)
        *b2=0;
    else if(counter_digits==6)
        *b1=0;
    else if(counter_digits==7)
        *b0=0;

    counter_digits++;
    }
}

void get_number_components (unsigned char number, char* b7, char* b6, char* b5, char* b4, char* b3, char* b2, char* b1, char* b0)
{
    int counter_digits=0; /* Counter of digits */
    unsigned char digit;
while(number!=0){                /* Converting decimal number to binary */
    digit=number%2;

    if(counter_digits==0)
        *b0=digit;
    else if(counter_digits==1)
        *b1=digit;
    else if(counter_digits==2)
        *b2=digit;
    else if(counter_digits==3)
        *b3=digit;
    else if(counter_digits==4)
        *b4=digit;
    else if(counter_digits==5)
        *b5=digit;
    else if(counter_digits==6)
        *b6=digit;
    else if(counter_digits==7)
        *b7=digit;
    
    counter_digits++;  /* Total digit count of binary representation */
    number/=2;
    }
    assing_zero(counter_digits,b7,b6,b5,b4,b3,b2,b1,b0); 

}                              
                
void reconstruct_components (unsigned char* number, char b7, char b6, char b5, char b4, char b3, char b2, char b1, char b0)
{
    *number=(b0*pow(2,7))+(b1*pow(2,6))+(b6*pow(2,5))+(b7*pow(2,4))+(b4*pow(2,3))+(b5*pow(2,2))+(b2*2)+b3;   
       /* Converting binary to decimal according to given algorithm on PDF */
}
