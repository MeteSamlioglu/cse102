/*
** main.c:
**
** The test/driver program for the homework.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.04.02.23.55
** 
*/


#include <stdio.h>
#include "hw5_lib.h"


void test_operate_polynomials () 
{
	char operator;
	double a3, a2, a1, a0, b3, b2, b1, b0;
	printf("Operators:\n+\n-\n*\nEnter the operator: ");
	scanf("%c",&operator);
	switch(operator){
		case '+':
			operate_polynomials(&a3,&a2,&a1,&a0,&b3,&b2,&b1,&b0,operator);
			printf("\nCoeff of x^3 = %f\nCoeff of x^2 = %f\nCoeff of x = %f\nCoeff of Constant(C)= %f\n",a3,a2,a1,a0);
		break;
		case '-':
			operate_polynomials(&a3,&a2,&a1,&a0,&b3,&b2,&b1,&b0,operator);
			printf("\nCoeff of x^3 = %f\nCoeff of x^2 = %f\nCoeff of x = %f\nCoeff of Constant(C)= %f\n",a3,a2,a1,a0);
		break;
		case '*':
			operate_polynomials(&a3,&a2,&a1,&a0,&b3,&b2,&b1,&b0,operator);
			printf("\nCoeff of x^6 = %f\nCoeff of x^5 = %f\nCoeff of x^4 = %f\nCoeff of x^3 = %f\n",a3,a2,a1,a0);
			printf("Coeff of x^2 = %f\nCoeff of x = %f\nCoeff of Constant(C)=%f\n",b3,b2,b1);
		break;
		default:
			printf("ERROR: The operator you choosed does not exits !...");
		break;
	}
	
}


void test_four_d_vectors ()
{
	double mean_a0=0.0, mean_a1=0.0, mean_a2=0.0, mean_a3=0.0, longest_distance=0.0;
	int N=5;
	four_d_vectors (&mean_a0, &mean_a1, &mean_a2, &mean_a3, &longest_distance, N);
	printf("Mean a0: %f\nMean a1: %f\nMean a2: %f\nMean a3: %f\nThe longest distance between two points: %f\n\n\n", mean_a0, mean_a1, mean_a2, mean_a3, longest_distance);
}


void test_dhondt_method ()
{
	int partyA=100000, partyB=80000, partyC=30000, partyD=20000, partyE=10000, numberOfSeats=550;
	
	dhondt_method (&partyA, &partyB, &partyC, &partyD, &partyE, numberOfSeats);
	printf("Party A: %d seat(s).\nParty B: %d seat(s).\nParty C: %d seat(s).\nParty D: %d seat(s).\nParty E: %d seat(s).\n\n\n", partyA, partyB, partyC, partyD, partyE);
}


void test_order_2d_points_cc ()
{
	double x1=0.0, y1=0.0, x2=0.0, y2=0.0, x3=0.0, y3=0.0;
	order_2d_points_cc (&x1, &y1, &x2, &y2, &x3, &y3);
	printf("Counter-Clockwise Order: (%f,%f) - (%f,%f) - (%f,%f)\n\n\n", x1, y1, x2, y2, x3, y3);
}


void test_number_encrypt ()
{
	unsigned char number=125;
    number_encrypt (&number); 
	printf("Encrypted number: %d\n\n\n", number);
}


/*
** main function for testing the functions...
**
*/
int main(void) {
	test_operate_polynomials ();
	test_four_d_vectors (); 
	test_dhondt_method ();
	test_order_2d_points_cc (); /* I couldn't solve this part */
	test_number_encrypt (); 
	return (0);
} 

/* Mehmet Mete Şamlıoğlu */
/* 200104004093 */