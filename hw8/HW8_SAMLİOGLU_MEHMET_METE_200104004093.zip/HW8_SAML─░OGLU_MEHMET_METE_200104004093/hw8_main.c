/*
** main.c:
**
** The test/driver program for the homework.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.04.22.19.55
** 
*/


#include <stdio.h>
#include "hw8_lib.h"
#define WORDSIZE 20

void test_clean_file () 
{
	char input_file_name[]="input.txt";
    char output_file_name[]="output.txt";
    char *words_to_delete[WORDSIZE]={"Mehmet","Mete","Samlioglu","Son"};
	int deleted_word_count=4; /* Size of words_to_delete function (Silinecek kelime sayisi,words_to_delete array'nin string sayisi) */
    clean_file(input_file_name,output_file_name,words_to_delete,4);
}


void test_maze_move ()
{
printf("To be implented");
}


void test_towers_of_hanoi ()
{
int n=3;
towers_of_hanoi('A','C','B',n); /* It doesn't work as expected, there is a problem in it but i couln't find enough time to solve it */
}


/*
** main function for testing the functions...
**
*/
int main(void) {
	test_clean_file ();
	printf("\n\n");
	test_towers_of_hanoi ();
	return (0);
} /* end main */
