/*
** hw8_lib.c:
**
** The source file implementing library functions.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.04.22.19.55
** 
*/

#include <stdio.h>
#include "hw8_lib.h"
#define WORDSIZE 20


void string_copy(char* str1,char* str2){ /* Recursion string copy function */

    if(str2[0]=='\0' || str2[0]=='.')
        str1[0]='\0';
    else{
        str1[0]=str2[0];
        string_copy(&str1[1],&str2[1]);
    }

}

int string_length(char word[WORDSIZE]){ /* This function finds the character length of given string */
    int ans;
    if(word[0]=='\0')
        ans=0;
    else
        ans=1+string_length(&word[1]);
    return ans;
}

int string_compare(char* word1,char* word2){ /* This function compares two string and check whether they are the same or not */
    int ans=0;
    
        if(word1[0]!=word2[0])
            ans=1;
        else if(word1[0]=='\0' && word2[0]=='\0')
            return ans;
        else
            ans=string_compare(&word1[1],&word2[1]);
    
    return ans;
}

int word_delete_check(char* words[WORDSIZE],char word[WORDSIZE],char line_word[WORDSIZE],int word_count){/*If given words array includes line string it will return 1 else return 0*/
    
    if(word_count<0)
        return 0;
    if(string_compare(line_word,word)==0)
        return 1;
    else
        word_delete_check(words,(*words++),line_word,word_count-1); 
    
}

void delete_words(FILE *infid,FILE* outfid,char* words_to_delete[WORDSIZE], int number_of_words){
    char str[WORDSIZE];
    
    
    if(fscanf(infid,"%s",str)!=1){
        fclose(infid);
        fclose(outfid);
    }
    else{
            if(str[string_length(str)-1]=='.'){
                string_copy(str,str);
                if(word_delete_check(words_to_delete,*(words_to_delete),str,4)!=1){
                    fprintf(outfid,"%s.\n",str);
                }
                else
                    fputs(".\n",outfid);

             }
            else{
                if(word_delete_check(words_to_delete,*(words_to_delete),str,4)!=1){
                    fprintf(outfid,"%s ",str);
                }
            }
        delete_words(infid,outfid,words_to_delete,number_of_words);
    }
 }

void clean_file(char* infile, char * outfile, char* words_to_delete[WORDSIZE], int number_of_words)
{
	FILE* infid;
	FILE* outfid;
	infid=fopen(("%s",infile),"r");  /* Read infile.txt */
	outfid=fopen(("%s",outfile),"w"); /* Write to outfile.txt */
	delete_words(infid,outfid,words_to_delete,number_of_words); 
}






int maze_move(cell_type maze[][8], cell_type player, move_type move)
{
	printf("TO BE IMPLEMENTED\n");
	return -1;
}




void print_disk_number(int horizantonal, int disk_number){
    int i=0;
    printf("*");
    for(i=2; i<horizantonal; ++i){       /* Print inside of the box */
        if(i==1+(horizantonal)/2)
            printf("%d",disk_number);
        else
            printf(" ");
    }
    printf("*");
}

int horizantonal_print(int disk_number){     /* Count of * character for borders */
    int i=0, j=0;
    int horizantonal=0;
    horizantonal=2*disk_number+3;
    return horizantonal;
}

void print_disks(int disk_a, int disk_b, int disk_c){
    int i=0,j=0;
    
      
        if(disk_a!=0){                                      /* Printing boxes simultaneously */
            for(j=0; j<horizantonal_print(disk_a); ++j)
                printf("*");
             printf("\t\t\t");
        }
        else
           printf("\t\t\t");
        if(disk_b!=0){
            for(j=0; j<horizantonal_print(disk_b); ++j)
                printf("*");
             printf("\t\t\t");
        }
        else
            printf("\t\t\t");
        if(disk_c!=0){
            for(j=0; j<horizantonal_print(disk_c); ++j)
                printf("*");
        printf("\n");
        }
        else
            printf("\n");
        
        if(disk_a!=0){
            print_disk_number(horizantonal_print(disk_a),disk_a);
             printf("\t\t\t");
        }
        else
             printf("\t\t\t");
         if(disk_b!=0){
            print_disk_number(horizantonal_print(disk_b),disk_b);
             printf("\t\t\t");
        }
        else
             printf("\t\t\t");
         if(disk_c!=0){
            print_disk_number(horizantonal_print(disk_c),disk_c);
            printf("\n");
        }
        else
            printf("\n");
          
          if(disk_a!=0){
            for(j=0; j<horizantonal_print(disk_a); ++j)
                printf("*");
             printf("\t\t\t");
        }
        else
             printf("\t\t\t");
        if(disk_b!=0){
            for(j=0; j<horizantonal_print(disk_b); ++j)
                printf("*");
            
         printf("\t\t\t");
        }
        else
            printf("\t\t\t");
        if(disk_c!=0){
            for(j=0; j<horizantonal_print(disk_c); ++j)
                printf("*");
        }

}


void print_steps(int *A,int *B, int *C,int disk_count){
int i=0;
printf("A");
printf("\t\t\t");                                             /* Printing towers */
printf("B");
printf("\t\t\t");
printf("C");
printf("\n");
    for(i=disk_count-1; i>=0; i--){
        print_disks(A[i], B[i], C[i]);
        printf("\n");
    }

printf("-------------------------------------------------------");
printf("\n");
}
void set_initial_pegs(int peg[7]){
    int i=0, k=0;
    for(i=0; i<7; ++i){
        peg[i]=0;
    }
}

void make_move(int *A,int *B,int *C,int disk_count,int n,char start_peg,char end_peg){
int i=0;
if(start_peg=='A' && end_peg=='B'){
    for(i=0; i<disk_count;++i){
        if(A[i]==n){
            A[i]=0;
            break;
        }
    }
    for(i=0; i<disk_count;++i){
        if(B[i]==0){
            B[i]=n;
            break;
        }
    }
}
else if(start_peg=='A' && end_peg=='C'){
    for(i=0; i<disk_count;++i){
        if(A[i]==n){
            A[i]=0;
            break;
        }
    }
    for(i=0; i<disk_count;++i){
        if(C[i]==0){
            C[i]=n;
            break;
        }
    }
}
else if(start_peg=='B' && end_peg=='C'){
    for(i=0; i<disk_count;++i){
        if(B[i]==n){
            B[i]=0;
            break;
        }
    }
    for(i=0; i<disk_count;++i){
        if(C[i]==0){
            C[i]=n;
            break;
        }
    }
}
else if(start_peg=='B' && end_peg=='A'){
    for(i=0; i<disk_count;++i){
        if(B[i]==n){
            B[i]=0;
            break;
        }
    }
    for(i=0; i<disk_count;++i){
        if(A[i]==0){
            A[i]=n;
            break;
        }
    }
}
else if(start_peg=='C' && end_peg=='A'){
    for(i=0; i<disk_count;++i){
        if(C[i]==n){
            C[i]=0;
            break;
        }
    }
    for(i=0; i<disk_count;++i){
        if(A[i]==0){
            A[i]=n;
            break;
        }
    }
}
else if(start_peg=='C' && end_peg=='B'){
    for(i=0; i<disk_count;++i){
        if(C[i]==n){
            C[i]=0;
            break;
        }
    }
    for(i=0; i<disk_count;++i){
        if(B[i]==0){
            B[i]=n;
            break;
        }
    }
}
print_steps(A,B,C,disk_count);

}

void print_tower_game(char start_peg,char end_peg,char aux_peg,int n, int disk_count,int *A, int *B,int *C){ /* Recursion hanoi calculation */
        
    if(n==1){
       make_move(A,B,C,disk_count,n,start_peg,end_peg);
    }
    else{
        print_tower_game(start_peg, aux_peg, end_peg, n-1,disk_count,A,B,C);
        make_move(A,B,C,disk_count,n,start_peg,end_peg);
        print_tower_game(aux_peg, end_peg,start_peg, n-1,disk_count,A,B,C);
    }


}

void towers_of_hanoi(char start_peg,char end_peg,char aux_peg,int n){ /* Initial set up for recursion function */
    int i=0, j=0, index_start_peg=0;
    int disk_count=n;
    int peg_A[7], peg_B[7], peg_C[7];
    set_initial_pegs(peg_A);
    set_initial_pegs(peg_B);
    set_initial_pegs(peg_C);
    for(i=n;i>=0;i--){
        peg_A[index_start_peg]=i;
        index_start_peg++;
    }
    
    print_steps(peg_A,peg_B,peg_C,disk_count);
    printf("\n");
    print_tower_game(start_peg,end_peg,aux_peg,n,disk_count,peg_A,peg_B,peg_C);

}   





